package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import commands.CommandsFactory;
import commands.DocumentToSpeech;
import commands.EditDocument;
import commands.LineToSpeech;
import commands.NewDocument;
import commands.OpenDocument;
import commands.ReplayCommand;
import commands.ReplayManager;
import commands.SaveDocument;
import commands.TuneAudio;
import commands.TuneEncoding;
import model.Document;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.FreeTTSAdapter;
import text2speechapis.TextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;

import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class TextToSpeechEditorView {

	private JFrame frame;
	private JTextArea textArea = new JTextArea();
	private Document currentDocument;
	private CommandsFactory commandsFactory = new CommandsFactory(this);
	private TextToSpeechAPIFactory apiFactory = new TextToSpeechAPIFactory();
	private JTextField textFieldTitle;
	private JTextField textFieldAuthor;
	private TextToSpeechAPI audioManager;
	private JTextField textFieldFilename;
	private JRadioButton radioButtonAtBash = new JRadioButton("AtBash");
	private JRadioButton radioButtonRot13 = new JRadioButton("Rot13");
	private JTextField textFieldLine;
	private JRadioButton radioButtonReversed = new JRadioButton("Reversed");
	private JRadioButton radioButtonEncoded = new JRadioButton("Encoded");
	private JTextField textFieldVolume;
	private JTextField textFieldPitch;
	private JTextField textFieldRate;
	private ReplayManager replayManager = new ReplayManager();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TextToSpeechEditorView window = new TextToSpeechEditorView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TextToSpeechEditorView() {
		audioManager = apiFactory.createTTSAPI("freetts");
		initialize();
	}

	public TextToSpeechEditorView(String api) {
		audioManager = apiFactory.createTTSAPI("fake");
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 883, 505);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 818, 117);
		frame.getContentPane().add(scrollPane);
		scrollPane.setViewportView(textArea);
		
		JButton buttonNewDocument = new JButton("New Document");
		buttonNewDocument.addActionListener(commandsFactory.createCommand("new"));
		buttonNewDocument.setBounds(10, 158, 140, 21);
		frame.getContentPane().add(buttonNewDocument);
		
		JRadioButton radioButtonNormal = new JRadioButton("Normal");
		radioButtonNormal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				radioButtonReversed.setSelected(false);
				radioButtonEncoded.setSelected(false);
			}
		});
		radioButtonNormal.setBounds(529, 270, 103, 21);
		frame.getContentPane().add(radioButtonNormal);
		radioButtonReversed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				radioButtonNormal.setSelected(false);
				radioButtonEncoded.setSelected(false);
			}
		});
		
		
		radioButtonReversed.setBounds(529, 369, 103, 21);
		frame.getContentPane().add(radioButtonReversed);
		radioButtonEncoded.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				radioButtonReversed.setSelected(false);
				radioButtonNormal.setSelected(false);
			}
		});
		
		radioButtonEncoded.setBounds(529, 322, 103, 21);
		frame.getContentPane().add(radioButtonEncoded);
		
		JButton buttonEditDocument = new JButton("Edit Document");
		buttonEditDocument.addActionListener(commandsFactory.createCommand("edit"));
		buttonEditDocument.setBounds(179, 158, 140, 20);
		frame.getContentPane().add(buttonEditDocument);
		
		JButton buttonSaveDocument = new JButton("Save Document");
		buttonSaveDocument.addActionListener(commandsFactory.createCommand("save"));
		buttonSaveDocument.setBounds(354, 158, 140, 20);
		frame.getContentPane().add(buttonSaveDocument);
		
		JButton buttonOpenDocument = new JButton("Open Document");
		buttonOpenDocument.addActionListener(commandsFactory.createCommand("open"));
		buttonOpenDocument.setBounds(519, 158, 140, 20);
		frame.getContentPane().add(buttonOpenDocument);
		
		JButton buttonDocumentToSpeech = new JButton("Document to Speech");
		buttonDocumentToSpeech.addActionListener(commandsFactory.createCommand("speakDocument"));
		buttonDocumentToSpeech.setBounds(673, 158, 155, 20);
		frame.getContentPane().add(buttonDocumentToSpeech);
		
		JButton buttonLineToSpeech = new JButton("Line to Speech");
		buttonLineToSpeech.addActionListener(commandsFactory.createCommand("speakLine"));
		buttonLineToSpeech.setBounds(10, 208, 140, 20);
		frame.getContentPane().add(buttonLineToSpeech);
		
		JButton buttonReplayCommands = new JButton("Replay Commands");
		buttonReplayCommands.addActionListener(commandsFactory.createCommand("replay"));
		buttonReplayCommands.setBounds(179, 208, 140, 20);
		frame.getContentPane().add(buttonReplayCommands);
		
		textFieldTitle = new JTextField();
		textFieldTitle.setBounds(10, 298, 96, 19);
		frame.getContentPane().add(textFieldTitle);
		textFieldTitle.setColumns(10);
		
		textFieldAuthor = new JTextField();
		textFieldAuthor.setBounds(179, 298, 96, 19);
		frame.getContentPane().add(textFieldAuthor);
		textFieldAuthor.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Title");
		lblNewLabel.setBounds(10, 257, 93, 13);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Author");
		lblNewLabel_1.setBounds(179, 257, 45, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Filename");
		lblNewLabel_2.setBounds(354, 257, 96, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		textFieldFilename = new JTextField();
		textFieldFilename.setBounds(354, 298, 96, 19);
		frame.getContentPane().add(textFieldFilename);
		textFieldFilename.setColumns(10);
		
		JButton buttonBrowse = new JButton("Browse");
		buttonBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser(".");
				int option = fileChooser.showOpenDialog(null);
				if(option == JFileChooser.APPROVE_OPTION) {
					String filename = fileChooser.getSelectedFile().getAbsolutePath();
					textFieldFilename.setText(filename);
				}
			}
		});
		buttonBrowse.setBounds(354, 208, 140, 20);
		frame.getContentPane().add(buttonBrowse);
		radioButtonAtBash.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				radioButtonRot13.setSelected(false);
			}
		});
		
		
		radioButtonAtBash.setBounds(675, 270, 103, 21);
		frame.getContentPane().add(radioButtonAtBash);
		radioButtonRot13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				radioButtonAtBash.setSelected(false);
			}
		});
		
		radioButtonRot13.setBounds(673, 322, 103, 21);
		frame.getContentPane().add(radioButtonRot13);
		
		JButton buttonTune = new JButton("Tune encoding");
		buttonTune.addActionListener(commandsFactory.createCommand("tune"));
		buttonTune.setBounds(519, 208, 140, 20);
		frame.getContentPane().add(buttonTune);
		
		JLabel Line = new JLabel("Line number");
		Line.setBounds(529, 414, 79, 13);
		frame.getContentPane().add(Line);
		
		textFieldLine = new JTextField();
		textFieldLine.setText("");
		textFieldLine.setBounds(673, 411, 96, 19);
		frame.getContentPane().add(textFieldLine);
		textFieldLine.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Volume");
		lblNewLabel_3.setBounds(10, 361, 45, 13);
		frame.getContentPane().add(lblNewLabel_3);
		
		textFieldVolume = new JTextField();
		textFieldVolume.setBounds(10, 397, 96, 19);
		frame.getContentPane().add(textFieldVolume);
		textFieldVolume.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Pitch");
		lblNewLabel_4.setBounds(179, 361, 45, 13);
		frame.getContentPane().add(lblNewLabel_4);
		
		textFieldPitch = new JTextField();
		textFieldPitch.setBounds(179, 397, 96, 19);
		frame.getContentPane().add(textFieldPitch);
		textFieldPitch.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Rate");
		lblNewLabel_5.setBounds(354, 361, 45, 13);
		frame.getContentPane().add(lblNewLabel_5);
		
		textFieldRate = new JTextField();
		textFieldRate.setBounds(354, 397, 96, 19);
		frame.getContentPane().add(textFieldRate);
		textFieldRate.setColumns(10);
		
		JButton btnNewButton = new JButton("Tune audio");
		btnNewButton.addActionListener(commandsFactory.createCommand("tuneAudio"));
		btnNewButton.setBounds(673, 208, 155, 20);
		frame.getContentPane().add(btnNewButton);
	}

	public Document getCurrentDocument() {
		return currentDocument;
	}

	public void setCurrentDocument(Document currentDocument) {
		this.currentDocument = currentDocument;
	}

	public JTextArea getTextArea() {
		return textArea;
	}

	public JTextField getTextFieldTitle() {
		return textFieldTitle;
	}

	public JTextField getTextFieldAuthor() {
		return textFieldAuthor;
	}

	public JTextField getTextFieldLine() {
		return textFieldLine;
	}
	public TextToSpeechAPI getAudioManager() {
		return audioManager;
	}

	public JTextField getTextFieldFilename() {
		return textFieldFilename;
	}

	public JRadioButton getRadioButtonAtBash() {
		return radioButtonAtBash;
	}

	public JRadioButton getRadioButtonRot13() {
		return radioButtonRot13;
	}

	public JRadioButton getRadioButtonReversed() {
		return radioButtonReversed;
	}


	public JRadioButton getRadioButtonEncoded() {
		return radioButtonEncoded;
	}


	
	public boolean isEncoded() {
		return radioButtonEncoded.isSelected();
	}
	public boolean isReversed() {
		return radioButtonReversed.isSelected();
	}
	
	public CommandsFactory getCommandsFactory() {
		return commandsFactory;
	}

	public JTextField getTextFieldVolume() {
		return textFieldVolume;
	}

	public JTextField getTextFieldPitch() {
		return textFieldPitch;
	}

	public JTextField getTextFieldRate() {
		return textFieldRate;
	}
	
	public void addCommand(ActionListener command) {
		TextToSpeechEditorView other = new TextToSpeechEditorView(this);
		CommandsFactory factory = other.getCommandsFactory();
		String type = typeOfCommand(command);
		replayManager.addCommand(factory.createCommand(type));
	}

	private String typeOfCommand(ActionListener command) {
		// TODO Auto-generated method stub
		if(command instanceof NewDocument)
			return "new";
		if(command instanceof EditDocument)
			return "edit";
		if(command instanceof SaveDocument)
			return "save";
		if(command instanceof OpenDocument)
			return "open";
		if(command instanceof DocumentToSpeech)
				return "speakDocument";
		if(command instanceof LineToSpeech)
			return "speakLine";
		if(command instanceof TuneEncoding)
			return "tune";
		if(command instanceof TuneAudio)
			return "tuneAudio";
		return null;
	}

	public ReplayManager getReplayManager() {
		// TODO Auto-generated method stub
		return replayManager;
	}


	
	public TextToSpeechEditorView(TextToSpeechEditorView other) {
		audioManager = apiFactory.createTTSAPI("freetts");
		initialize();
		textArea.setText(other.textArea.getText());
		textFieldRate.setText(other.textFieldRate.getText());
		textFieldPitch.setText(other.textFieldPitch.getText());
		textFieldVolume.setText(other.textFieldVolume.getText());
		radioButtonReversed.setSelected(other.radioButtonReversed.isSelected());
		radioButtonEncoded.setSelected(other.radioButtonEncoded.isSelected());
		textFieldLine.setText(other.textFieldLine.getText());
		radioButtonAtBash.setSelected(other.radioButtonAtBash.isSelected());
		radioButtonRot13.setSelected(other.radioButtonRot13.isSelected());
		textFieldFilename.setText(other.textFieldFilename.getText());
		textFieldAuthor.setText(other.textFieldAuthor.getText());
		
		if(other.audioManager instanceof FreeTTSAdapter)
			audioManager = new FreeTTSAdapter(other.audioManager);
		else
			audioManager = new FakeTextToSpeechAPI(other.audioManager);
		textFieldTitle.setText(other.textFieldTitle.getText());
		
		if(other.currentDocument != null)
			currentDocument = new Document(other.currentDocument, audioManager);
	}
}
