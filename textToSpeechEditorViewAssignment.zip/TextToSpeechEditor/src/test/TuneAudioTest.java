package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class TuneAudioTest {

	@Test
	void test() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		textToSpeechEditorView.getTextFieldVolume().setText("80");
		textToSpeechEditorView.getTextFieldPitch().setText("90");
		textToSpeechEditorView.getTextFieldRate().setText("100");
		
		ActionListener tuneAudio = commandsFactory.createCommand("tuneAudio");
		tuneAudio.actionPerformed(null);
		
		FakeTextToSpeechAPI audioManager = (FakeTextToSpeechAPI) textToSpeechEditorView.getAudioManager();
		
		
		assertEquals(audioManager.getVolume(), 0.80, 0.000001);
		assertEquals(audioManager.getPitch(), 90);
		assertEquals(audioManager.getRate(), 100);
		
	}

}
