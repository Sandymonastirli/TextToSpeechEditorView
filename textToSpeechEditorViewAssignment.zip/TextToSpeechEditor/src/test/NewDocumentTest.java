package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class NewDocumentTest {

	@Test
	void test() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView();
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		String contents = textToSpeechEditorView.getCurrentDocument().getContents();
		assertEquals("", contents);
	}

}
