package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import commands.TuneEncoding;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class DocumentToSpeechTest {

	@Test
	void test1() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextArea().setText("This is a test\nthis is a perfect test\nthis is an awesome test");
		
		ActionListener editDocument = commandsFactory.createCommand("edit");
		editDocument.actionPerformed(null);
		
		ActionListener documentToSpeech = commandsFactory.createCommand("speakDocument");
		documentToSpeech.actionPerformed(null);
		
		String contents = textToSpeechEditorView.getCurrentDocument().getContents();
		
		FakeTextToSpeechAPI audioManager = (FakeTextToSpeechAPI) textToSpeechEditorView.getAudioManager();
		
		
		assertEquals(audioManager.getContents(), contents);
		
	}

	@Test
	void test2() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextArea().setText("This is a test\nthis is a perfect test\nthis is an awesome test");
		
		ActionListener editDocument = commandsFactory.createCommand("edit");
		editDocument.actionPerformed(null);
		

		textToSpeechEditorView.getRadioButtonReversed().setSelected(true);
		ActionListener documentToSpeech = commandsFactory.createCommand("speakDocument");
		documentToSpeech.actionPerformed(null);
		
		String contents = textToSpeechEditorView.getCurrentDocument().getReverseContents();
		
		FakeTextToSpeechAPI audioManager = (FakeTextToSpeechAPI) textToSpeechEditorView.getAudioManager();
		
		
		assertEquals(audioManager.getContents(), contents);
		
	}
	
	@Test
	void test3() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextArea().setText("This is a test\nthis is a perfect test\nthis is an awesome test");
		
		ActionListener editDocument = commandsFactory.createCommand("edit");
		editDocument.actionPerformed(null);
		
		textToSpeechEditorView.getRadioButtonAtBash().setSelected(true);
		TuneEncoding tuneEncoding = (TuneEncoding) commandsFactory.createCommand("tune");
		tuneEncoding.actionPerformed(null);
		
		textToSpeechEditorView.getRadioButtonEncoded().setSelected(true);
		ActionListener documentToSpeech = commandsFactory.createCommand("speakDocument");
		documentToSpeech.actionPerformed(null);


		String contents = textToSpeechEditorView.getCurrentDocument().getEncodedContents();
		
		FakeTextToSpeechAPI audioManager = (FakeTextToSpeechAPI) textToSpeechEditorView.getAudioManager();
		
		
		assertEquals(audioManager.getContents(), contents);
		
	}
	
	
	@Test
	void test4() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextArea().setText("This is a test\nthis is a perfect test\nthis is an awesome test");
		
		ActionListener editDocument = commandsFactory.createCommand("edit");
		editDocument.actionPerformed(null);
		
		textToSpeechEditorView.getRadioButtonRot13().setSelected(true);
		TuneEncoding tuneEncoding = (TuneEncoding) commandsFactory.createCommand("tune");
		tuneEncoding.actionPerformed(null);
		
		textToSpeechEditorView.getRadioButtonEncoded().setSelected(true);
		ActionListener documentToSpeech = commandsFactory.createCommand("speakDocument");
		documentToSpeech.actionPerformed(null);


		String contents = textToSpeechEditorView.getCurrentDocument().getEncodedContents();
		
		FakeTextToSpeechAPI audioManager = (FakeTextToSpeechAPI) textToSpeechEditorView.getAudioManager();
		
		
		assertEquals(audioManager.getContents(), contents);
		
	}
	
}
