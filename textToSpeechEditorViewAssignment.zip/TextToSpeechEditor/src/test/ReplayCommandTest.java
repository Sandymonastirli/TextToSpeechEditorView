package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import commands.TuneEncoding;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class ReplayCommandTest {

	@Test
	void test1() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextArea().setText("This is a test\nthis is a perfect test\nthis is an awesome test");
		
		ActionListener editDocument = commandsFactory.createCommand("edit");
		editDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextFieldFilename().setText("test.txt");
		ActionListener saveDocument = commandsFactory.createCommand("save");
		saveDocument.actionPerformed(null);
		
		ActionListener openDocument = commandsFactory.createCommand("open");
		openDocument.actionPerformed(null);
		
		
		ActionListener documentToSpeech = commandsFactory.createCommand("speakDocument");
		documentToSpeech.actionPerformed(null);
		
		String contents = textToSpeechEditorView.getCurrentDocument().getContents();
		
		FakeTextToSpeechAPI audioManager = (FakeTextToSpeechAPI) textToSpeechEditorView.getAudioManager();
		
		ActionListener replayCommand = commandsFactory.createCommand("replay");
		replayCommand.actionPerformed(null);
		assertEquals(audioManager.getContents(), contents);
		
	}
}
