package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class EditDocumentTest {

	@Test
	void test() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView();
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextArea().setText("This is a test\nthis is a perfect test\nthis is an awesome test");
		
		ActionListener editDocument = commandsFactory.createCommand("edit");
		editDocument.actionPerformed(null);
		
		String contents = textToSpeechEditorView.getCurrentDocument().getContents();
		assertEquals("This is a test\nthis is a perfect test\nthis is an awesome test", contents);
	}

}
