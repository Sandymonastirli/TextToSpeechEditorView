package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class OpenDocumentTest {

	@Test
	void test() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView();
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
	
		
		textToSpeechEditorView.getTextFieldFilename().setText("test.txt");
		ActionListener openDocument = commandsFactory.createCommand("open");
		openDocument.actionPerformed(null);
		
		String contents = textToSpeechEditorView.getCurrentDocument().getContents();
		
		
		FileInputStream stream = null;
		
		try {
			stream = new FileInputStream("test.txt");
			Scanner scanner = new Scanner(stream);
			
			String text = "";
			if(scanner.hasNextLine()) {
				text = scanner.nextLine();
			}
			while(scanner.hasNextLine()) {
				text = text + "\n" + scanner.nextLine();
			}
			
			assertEquals(text, contents);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			
		}	
	}

}
