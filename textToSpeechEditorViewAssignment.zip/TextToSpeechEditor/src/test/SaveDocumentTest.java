package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class SaveDocumentTest {

	@Test
	void test() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView();
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getTextArea().setText("This is a test\nthis is a perfect test\nthis is an awesome test");
		
		ActionListener editDocument = commandsFactory.createCommand("edit");
		editDocument.actionPerformed(null);
		
		textToSpeechEditorView.getTextFieldFilename().setText("test.txt");
		ActionListener saveDocument = commandsFactory.createCommand("save");
		saveDocument.actionPerformed(null);
		
		String contents = textToSpeechEditorView.getCurrentDocument().getContents();
		
		
		FileInputStream stream = null;
		
		try {
			stream = new FileInputStream("test.txt");
			Scanner scanner = new Scanner(stream);
			
			String text = "";
			if(scanner.hasNextLine()) {
				text = scanner.nextLine();
			}
			while(scanner.hasNextLine()) {
				text = text + "\n" + scanner.nextLine();
			}
			
			assertEquals(text, contents);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			
		}	
	}

}
