package test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JOptionPane;

import org.junit.jupiter.api.Test;

import commands.CommandsFactory;
import commands.TuneEncoding;
import encodingstrategies.AtBashEncoding;
import encodingstrategies.EncodingStrategy;
import encodingstrategies.Rot13Encoding;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.TextToSpeechEditorView;

class TuneEncodingTest {

	@Test
	void test1() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getRadioButtonAtBash().setSelected(true);
		TuneEncoding tuneEncoding = (TuneEncoding) commandsFactory.createCommand("tune");
		tuneEncoding.actionPerformed(null);
		
		
		EncodingStrategy encodingStrategy = textToSpeechEditorView.getCurrentDocument().getEncodingStrategy();
		
		assertEquals(true, encodingStrategy instanceof AtBashEncoding);
		
	}
	
	
	@Test
	void test2() {
		TextToSpeechEditorView textToSpeechEditorView = new TextToSpeechEditorView("fake");
		CommandsFactory commandsFactory = textToSpeechEditorView.getCommandsFactory();
		
		ActionListener newDocument = commandsFactory.createCommand("new");
		newDocument.actionPerformed(null);
		
		
		textToSpeechEditorView.getRadioButtonRot13().setSelected(true);
		TuneEncoding tuneEncoding = (TuneEncoding) commandsFactory.createCommand("tune");
		tuneEncoding.actionPerformed(null);
		
		
		EncodingStrategy encodingStrategy = textToSpeechEditorView.getCurrentDocument().getEncodingStrategy();
		
		assertEquals(true, encodingStrategy instanceof Rot13Encoding);
		
	}
	
}
