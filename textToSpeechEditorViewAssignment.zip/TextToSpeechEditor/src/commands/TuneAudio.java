package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import text2speechapis.TextToSpeechAPI;
import view.TextToSpeechEditorView;

public class TuneAudio implements ActionListener {
	private TextToSpeechEditorView textToSpeechEditorView;
	
	public TuneAudio(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.textToSpeechEditorView = textToSpeechEditorView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		String volumeString = textToSpeechEditorView.getTextFieldVolume().getText();
		String rateString = textToSpeechEditorView.getTextFieldRate().getText();
		String pitchString = textToSpeechEditorView.getTextFieldPitch().getText();
		
		if(volumeString.equals("") && rateString.equals("") && pitchString.equals("")) {
			JOptionPane.showMessageDialog(null, "Give one parameter");
		}
		else {
			TextToSpeechAPI audioManager = textToSpeechEditorView.getAudioManager();
			if(volumeString.equals("") == false) {
				try {
					int volume = Integer.parseInt(volumeString);
					if(volume >=0 && volume <= 100) {
						audioManager.setVolume(volume);
					}
					else {
						JOptionPane.showMessageDialog(null, "Give correct volume");
						return;
					}
				}catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Give correct volume");
					return;
				}
			}
			
			
			if(rateString.equals("") == false) {
				try {
					int rate = Integer.parseInt(rateString);
					if(rate >= 0) {
						audioManager.setRate(rate);
					}
					else {
						JOptionPane.showMessageDialog(null, "Give correct rate");
						return;
					}
				}catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Give correct rate");
					return;
				}
				
			}
			

			if(pitchString.equals("") == false) {
				try {
					int pitch = Integer.parseInt(pitchString);
					if(pitch >=0) {
						audioManager.setPitch(pitch);
					}
					else {
						JOptionPane.showMessageDialog(null, "Give correct pitch");
						return;
					}
				}catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Give correct pitch");
					return;
				}
				
			}
		}
	}

}
