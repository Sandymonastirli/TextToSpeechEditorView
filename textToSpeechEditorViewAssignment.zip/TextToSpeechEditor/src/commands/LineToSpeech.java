package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.Document;
import view.TextToSpeechEditorView;

public class LineToSpeech implements ActionListener{

	private TextToSpeechEditorView textToSpeechEditorView;
	
	public LineToSpeech(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.textToSpeechEditorView = textToSpeechEditorView;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		Document currentDocument = textToSpeechEditorView.getCurrentDocument();
		String lineNumber = textToSpeechEditorView.getTextFieldLine().getText();
		try {
			int line = Integer.parseInt(lineNumber);
			if(line < 1 || line > currentDocument.getContentsSize()) {
				JOptionPane.showMessageDialog(null, "Number out of range");
			}
			else {
				if(textToSpeechEditorView.isReversed()) {
					currentDocument.playReverseLine(line-1);
				}
				else if(textToSpeechEditorView.isEncoded()) {
					currentDocument.playEncodedLine(line-1);
				}
				else {
					currentDocument.playLine(line-1);
				}
				
			}
		}catch(NumberFormatException ex) {
			JOptionPane.showMessageDialog(null, "Give a number");
		}
	}
}
