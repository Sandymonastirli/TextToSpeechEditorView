package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import encodingstrategies.EncodingStrategy;
import encodingstrategies.StrategiesFactory;
import model.Document;
import view.TextToSpeechEditorView;

public class TuneEncoding implements ActionListener{
	private TextToSpeechEditorView textToSpeechEditorView;
	private StrategiesFactory strategiesFactory;
	
	public TuneEncoding(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.textToSpeechEditorView = textToSpeechEditorView;
		this.strategiesFactory = new StrategiesFactory();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		String strategy = "";
		if(textToSpeechEditorView.getRadioButtonAtBash().isSelected()) {
			strategy = "atbash";
		}
		else if(textToSpeechEditorView.getRadioButtonRot13().isSelected()) {
			strategy = "rot13";
		}
		if(strategy.equals("")) {
			JOptionPane.showMessageDialog(null, "Select encoding strategy");
		}
		else {
			EncodingStrategy encodingStrategy = strategiesFactory.createStrategy(strategy);
			Document currentDocument = textToSpeechEditorView.getCurrentDocument();
			if(currentDocument != null) {
				currentDocument.tuneEncodingStrategy(encodingStrategy);
			}else {
				JOptionPane.showMessageDialog(null, "There is no current document.");
			}
		}
	}
	
}
