package commands;

import java.awt.event.ActionListener;

import view.TextToSpeechEditorView;

public class CommandsFactory {
	private TextToSpeechEditorView textToSpeechEditorView;
	
	public CommandsFactory(TextToSpeechEditorView textToSpeechEditorView) {
		this.textToSpeechEditorView = textToSpeechEditorView;
	}
	
	public ActionListener createCommand(String command) {
		if(command.equals("new"))
			return new NewDocument(textToSpeechEditorView);
		if(command.equals("edit"))
			return new EditDocument(textToSpeechEditorView);
		if(command.equals("save"))
			return new SaveDocument(textToSpeechEditorView);
		if(command.equals("open"))
			return new OpenDocument(textToSpeechEditorView);
		if(command.equals("speakDocument"))
			return new DocumentToSpeech(textToSpeechEditorView);
		if(command.equals("speakLine"))
			return new LineToSpeech(textToSpeechEditorView);
		if(command.equals("tune"))
			return new TuneEncoding(textToSpeechEditorView);
		if(command.equals("tuneAudio"))
			return new TuneAudio(textToSpeechEditorView);
		if(command.equals("replay"))
			return new ReplayCommand(textToSpeechEditorView);
		return null;
	}
}
