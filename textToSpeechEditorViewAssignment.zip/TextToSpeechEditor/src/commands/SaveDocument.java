package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

import model.Document;
import view.TextToSpeechEditorView;

public class SaveDocument implements ActionListener{
	private TextToSpeechEditorView textToSpeechEditorView;
	
	public SaveDocument(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.textToSpeechEditorView = textToSpeechEditorView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		Document currentDocument = textToSpeechEditorView.getCurrentDocument();
		
		if(currentDocument != null) {
			String filename = textToSpeechEditorView.getTextFieldFilename().getText();
			FileOutputStream stream = null;
			try {
				stream = new FileOutputStream(filename);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			PrintWriter printWriter = new PrintWriter(stream);
			
			printWriter.print(currentDocument.getContents());
			printWriter.close();
		}
		else {
			JOptionPane.showMessageDialog(null, "There is no current document.");
		}
	}

}
