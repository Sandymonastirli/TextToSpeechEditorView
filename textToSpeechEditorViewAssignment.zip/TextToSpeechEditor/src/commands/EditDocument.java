package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.Document;
import view.TextToSpeechEditorView;

public class EditDocument implements ActionListener{

	private TextToSpeechEditorView textToSpeechEditorView;
	
	public EditDocument(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.textToSpeechEditorView = textToSpeechEditorView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		Document currentDocument = textToSpeechEditorView.getCurrentDocument();
		String text = textToSpeechEditorView.getTextArea().getText();
		if(currentDocument != null) {
			currentDocument.setContents(text);
		}
		else {
			JOptionPane.showMessageDialog(null, "There is no current document.");
		}
		
	}

}
