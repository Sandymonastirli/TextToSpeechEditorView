package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JOptionPane;

import model.Document;
import text2speechapis.TextToSpeechAPI;
import view.TextToSpeechEditorView;

public class OpenDocument implements ActionListener{

private TextToSpeechEditorView textToSpeechEditorView;
	
	public OpenDocument(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.textToSpeechEditorView = textToSpeechEditorView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		String filename = textToSpeechEditorView.getTextFieldFilename().getText();
		
		FileInputStream stream = null;
		
		try {
			stream = new FileInputStream(filename);
			Scanner scanner = new Scanner(stream);
			
			String text = "";
			if(scanner.hasNextLine()) {
				text = scanner.nextLine();
			}
			while(scanner.hasNextLine()) {
				text = text + "\n" + scanner.nextLine();
			}
			
			TextToSpeechAPI audioManager = textToSpeechEditorView.getAudioManager();
			
			Document currentDocument = new Document(audioManager, "", "");
			currentDocument.setContents(text);
			
			textToSpeechEditorView.setCurrentDocument(currentDocument);
			textToSpeechEditorView.getTextArea().setText(text);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "File not found");
		}		
		
	}

}
