package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.TextToSpeechEditorView;

public class ReplayCommand implements ActionListener {
	private ReplayManager replayManager;
	
	public ReplayCommand(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.replayManager = textToSpeechEditorView.getReplayManager();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		replayManager.replay();
	}

}
