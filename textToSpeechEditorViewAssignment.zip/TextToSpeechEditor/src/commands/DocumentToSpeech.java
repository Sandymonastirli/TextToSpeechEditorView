package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Document;
import view.TextToSpeechEditorView;

public class DocumentToSpeech implements ActionListener{

	private TextToSpeechEditorView textToSpeechEditorView;
	
	public DocumentToSpeech(TextToSpeechEditorView textToSpeechEditorView) {
		// TODO Auto-generated constructor stub
		this.textToSpeechEditorView = textToSpeechEditorView;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		Document currentDocument = textToSpeechEditorView.getCurrentDocument();
		
		if(textToSpeechEditorView.isReversed()) {
			currentDocument.playReverseContents();
		}
		else if(textToSpeechEditorView.isEncoded()) {
			currentDocument.playEncodedContents();
		}
		else {
			currentDocument.playContents();
		}
		
	}

}
