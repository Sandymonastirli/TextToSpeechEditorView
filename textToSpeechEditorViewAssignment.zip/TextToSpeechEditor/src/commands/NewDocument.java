package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Document;
import text2speechapis.TextToSpeechAPI;
import view.TextToSpeechEditorView;

public class NewDocument implements ActionListener{
	private TextToSpeechEditorView textToSpeechEditorView;
	
	public NewDocument(TextToSpeechEditorView textToSpeechEditorView) {
		this.textToSpeechEditorView = textToSpeechEditorView;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		textToSpeechEditorView.addCommand(this);
		TextToSpeechAPI audioManager = textToSpeechEditorView.getAudioManager();
		String title = textToSpeechEditorView.getTextFieldTitle().getText();
		String author = textToSpeechEditorView.getTextFieldAuthor().getText();
		
		Document document = new Document(audioManager, title, author);
		textToSpeechEditorView.setCurrentDocument(document);
	}

}
