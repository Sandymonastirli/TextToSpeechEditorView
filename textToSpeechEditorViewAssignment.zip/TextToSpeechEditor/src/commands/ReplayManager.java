package commands;

import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ReplayManager {
	private ArrayList<ActionListener> commandsList;
	
	public ReplayManager() {
		commandsList = new ArrayList<ActionListener>();
	}
	
	public void replay() {
		int size = commandsList.size();
		for(int i = 0; i < size; i++) {
			commandsList.get(i).actionPerformed(null);
		}
		while(commandsList.size() > size) {
			int last = commandsList.size() - 1;
			commandsList.remove(last);
		}
	}
	
	public void addCommand(ActionListener command) {
		commandsList.add(command);
	}
}
