package text2speechapis;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class FreeTTSAdapter implements TextToSpeechAPI{
	private VoiceManager vm;
	private Voice voice;
	
	public FreeTTSAdapter() {
		System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
		vm = VoiceManager.getInstance();
		voice = vm.getVoice("kevin16");
		voice.allocate();
	}
	public FreeTTSAdapter(TextToSpeechAPI audioManager) {
		// TODO Auto-generated constructor stub
		System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
		vm = VoiceManager.getInstance();
		voice = vm.getVoice("kevin16");
		voice.allocate();
		
		voice.setVolume(((FreeTTSAdapter)audioManager).voice.getVolume());
		voice.setPitch(((FreeTTSAdapter)audioManager).voice.getPitch());
		voice.setRate(((FreeTTSAdapter)audioManager).voice.getRate());
	}
	@Override
	public void play(String contents) {
		// TODO Auto-generated method stub
		
		voice.speak(contents);
	}

	@Override
	public void setVolume(int volume) {
		// TODO Auto-generated method stub
		float vol = volume/(float)100;
		voice.setVolume(vol);
	}

	@Override
	public void setPitch(int pitch) {
		// TODO Auto-generated method stub
		voice.setPitch(pitch);
	}

	@Override
	public void setRate(int rate) {
		// TODO Auto-generated method stub
		voice.setRate(rate);
	}

}
