package text2speechapis;


public class TextToSpeechAPIFactory {

	public TextToSpeechAPI createTTSAPI(String api) {
		if(api.equals("freetts"))
			return new FreeTTSAdapter();
		if(api.equals("fake"))
			return new FakeTextToSpeechAPI();
		return null;
	}
}
