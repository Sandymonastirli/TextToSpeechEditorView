package text2speechapis;

public class FakeTextToSpeechAPI implements TextToSpeechAPI {
	private String contents;
	private float volume;
	private int pitch;
	private int rate;
	
	public FakeTextToSpeechAPI(TextToSpeechAPI audioManager) {
		// TODO Auto-generated constructor stub
		if(((FakeTextToSpeechAPI)audioManager).contents != null)
			contents = new String(((FakeTextToSpeechAPI)audioManager).contents);
		volume = ((FakeTextToSpeechAPI)audioManager).volume;
		pitch = ((FakeTextToSpeechAPI)audioManager).pitch;
		rate = ((FakeTextToSpeechAPI)audioManager).rate;

	}

	public FakeTextToSpeechAPI() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void play(String contents) {
		// TODO Auto-generated method stub
		this.contents = contents;
	}

	@Override
	public void setVolume(int volume) {
		// TODO Auto-generated method stub
		this.volume = volume/(float)100;
	}

	@Override
	public void setPitch(int pitch) {
		// TODO Auto-generated method stub
		this.pitch = pitch;
	}

	@Override
	public void setRate(int rate) {
		// TODO Auto-generated method stub
		this.rate = rate;
	}

	public String getContents() {
		return contents;
	}

	public float getVolume() {
		return volume;
	}

	public int getPitch() {
		return pitch;
	}

	public int getRate() {
		return rate;
	}
	
}
