package encodingstrategies;


public class StrategiesFactory {
	
	public EncodingStrategy createStrategy(String strategy) {
		if(strategy.equals("rot13"))
			return new Rot13Encoding();
		if(strategy.equals("atbash"))
			return new AtBashEncoding();
		return null;
	}
}
