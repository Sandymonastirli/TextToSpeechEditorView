package encodingstrategies;

public class AtBashEncoding extends TemplateEncoding{

	@Override
	protected char mapCharacter(char charToEncode) {
		// TODO Auto-generated method stub
		String lower = "abcdefghijklmnopqrstuvwxyz";
		String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		
		int index = lower.indexOf(charToEncode);
		if(index != -1) {
			return lower.charAt(25 - index);
		}
		else {
			index = upper.indexOf(charToEncode);
			return upper.charAt(25 - index);
		}
	}

}
