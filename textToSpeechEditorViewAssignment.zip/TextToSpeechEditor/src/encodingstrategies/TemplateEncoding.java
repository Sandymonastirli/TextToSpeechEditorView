package encodingstrategies;

public abstract class TemplateEncoding implements EncodingStrategy{

	@Override
	public String encode(String textToEncode) {
		// TODO Auto-generated method stub
		String encodedText = "";
		for(int i = 0; i < textToEncode.length(); i++) {
			char charToEncode = textToEncode.charAt(i);
			if(needsEncode(charToEncode)) {
				encodedText = encodedText + mapCharacter(charToEncode);
			}
			else {
				encodedText = encodedText + charToEncode;
			}
		}
		return encodedText;
	}
	
	private boolean needsEncode(char charToEncode) {
		// TODO Auto-generated method stub
		String letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		if( letters.indexOf(charToEncode) == -1)
			return false;
		return true;
	}
	protected abstract char mapCharacter(char charToEncode);

}
