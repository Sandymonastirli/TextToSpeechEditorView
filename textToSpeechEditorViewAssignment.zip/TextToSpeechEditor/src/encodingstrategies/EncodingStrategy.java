package encodingstrategies;

public interface EncodingStrategy {
	public String encode(String textToEncode);
}
