package model;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import encodingstrategies.EncodingStrategy;
import text2speechapis.TextToSpeechAPI;

public class Line {
	private EncodingStrategy encodingStrategy;
	private TextToSpeechAPI audioManager;
	private ArrayList<String> words;
	
	public Line(TextToSpeechAPI audioManager, ArrayList<String> words) {
		this.audioManager = audioManager;
		this.words = words;
	}


	public Line(Line other, TextToSpeechAPI audioManager, EncodingStrategy encodingStrategy) {
		// TODO Auto-generated constructor stub
		this.encodingStrategy = encodingStrategy;
		this.audioManager = audioManager;
		
		words = new ArrayList<String>();
		for(int i = 0; i < other.words.size(); i++) {
			String word = new String(other.words.get(i));
			words.add(word);
		}
	}


	public void playLine() {
		String str = "";
		if(words.size() >= 1) {
			str = str + words.get(0);

			for(int j = 1; j < words.size(); j++) {
				str = str + " "+ words.get(j);
			}
		}
		audioManager.play(str);
	}
	
	public void playReverseLine() {
		String str = "";
		if(words.size() >= 1) {
			str = str + words.get(words.size() - 1);

			for(int j = words.size() - 2; j >= 0 ; j--) {
				str = str + " "+ words.get(j);
			}
		}
		audioManager.play(str);
	}
	
	public void playEncodedLine() {
		
		if(encodingStrategy == null) {
			JOptionPane.showMessageDialog(null, "Encoding strategy is not defined");
		}
		else {
			String str = "";
			if(words.size() >= 1) {
				str = str + words.get(0);

				for(int j = 1; j < words.size(); j++) {
					str = str + " "+ words.get(j);
				}
			}
			
			str = encodingStrategy.encode(str);
			audioManager.play(str);
		}
	}
	
	public void tuneEncodingStrategy(EncodingStrategy encodingStrategy) {
		this.encodingStrategy = encodingStrategy;
	}


	public ArrayList<String> getWords() {
		// TODO Auto-generated method stub
		return words;
	}
}
