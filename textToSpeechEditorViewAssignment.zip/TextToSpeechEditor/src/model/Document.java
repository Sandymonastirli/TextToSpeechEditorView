package model;

import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;

import encodingstrategies.AtBashEncoding;
import encodingstrategies.EncodingStrategy;
import encodingstrategies.Rot13Encoding;
import text2speechapis.TextToSpeechAPI;

public class Document {
	private EncodingStrategy encodingStrategy;
	private TextToSpeechAPI audioManager;
	private String title;
	private String author;
	private ArrayList<Line> contents;
	private Date dateCreated;
	private Date dateSaved;
	
	public Document(TextToSpeechAPI audioManager, String title, String author) {
		this.audioManager = audioManager;
		this.title = title;
		this.author = author;
		this.contents = new ArrayList<Line>();
		this.dateCreated = new Date();
	}
	
	public Document(Document other, TextToSpeechAPI audioManager) {
		// TODO Auto-generated constructor stub
		if(other.encodingStrategy != null) {
			if(other.encodingStrategy instanceof AtBashEncoding)
				encodingStrategy = new AtBashEncoding();
			else
				encodingStrategy = new Rot13Encoding();
		}
		this.audioManager = audioManager;
		title = new String(other.title);
		author = new String(other.author);

		
		contents = new ArrayList<Line>();
		for(int i = 0; i < other.contents.size(); i++) {
			Line line = new Line(other.contents.get(i), audioManager, encodingStrategy);
			contents.add(line);
		}
	}

	public void playContents() {
		String str = getContents();
		audioManager.play(str);
	}
	
	public void playReverseContents() {
		String str = getReverseContents();
		audioManager.play(str);
	}
	
	public void playEncodedContents() {
		String str = getContents();
		if(encodingStrategy == null) {
			JOptionPane.showMessageDialog(null, "Encoding strategy is not defined");
		}
		else {
			str = encodingStrategy.encode(str);
			audioManager.play(str);
		}
	}
	
	public void playLine(int line) {
		contents.get(line).playLine();
	}
	
	public void playReverseLine(int line) {
		contents.get(line).playReverseLine();
	}
	
	public void playEncodedLine(int line) {
		contents.get(line).playEncodedLine();
	}
	
	public void tuneEncodingStrategy(EncodingStrategy encodingStrategy) {
		this.encodingStrategy = encodingStrategy;
		for(int i = 0; i < contents.size(); i++) {
			Line line = contents.get(i);
			line.tuneEncodingStrategy(encodingStrategy);
		}
	}

	public void setContents(String text) {
		// TODO Auto-generated method stub
		contents.clear();

		String[] lines = text.split("\n");
		for(int i = 0; i < lines.length; i++) {
			ArrayList<String> words = new ArrayList<String>();
			String[] w = lines[i].split(" ");
			for(int j = 0; j < w.length; j++) {
				words.add(w[j]);
			}
			Line line = new Line(audioManager, words);
			contents.add(line);
		}
	}

	public String getContents() {
		// TODO Auto-generated method stub
		String str = "";
		if(contents.size() >= 1) {
			Line line = contents.get(0);
			ArrayList<String> words = line.getWords();
			
			if(words.size() >= 1) {
				str = str + words.get(0);

				for(int j = 1; j < words.size(); j++) {
					str = str + " "+ words.get(j);
				}
			}
			
			for(int i = 1; i < contents.size(); i++) {
				str = str + "\n" ;
				line = contents.get(i);
				words = line.getWords();
				
				if(words.size() >= 1) {
					str = str + words.get(0);

					for(int j = 1; j < words.size(); j++) {
						str = str + " "+ words.get(j);
					}
				}
				
			}
		}
		
		
		return str;
	}
	public String getReverseContents() {
		// TODO Auto-generated method stub
		String str = "";
		if(contents.size() >= 1) {
			Line line = contents.get(contents.size() - 1);
			ArrayList<String> words = line.getWords();
			
			if(words.size() >= 1) {
				str = str + words.get(words.size() - 1);

				for(int j = words.size() - 2; j >= 0; j--) {
					str = str + " "+ words.get(j);
				}
			}
			
			for(int i = contents.size() - 2; i >= 0 ; i--) {
				str = str + "\n" ;
				line = contents.get(i);
				words = line.getWords();
				
				if(words.size() >= 1) {
					str = str + words.get(words.size() - 1);

					for(int j = words.size() - 2; j >= 0; j--) {
						str = str + " "+ words.get(j);
					}
				}
				
			}
		}
		
		
		return str;
	}
	
	public int getContentsSize() {
		return contents.size();
	}

	public String getEncodedContents() {
		// TODO Auto-generated method stub
		return encodingStrategy.encode(getContents());
	}

	public String getLine(int i) {
		// TODO Auto-generated method stub
		ArrayList<String> words = contents.get(i).getWords();
		String str = "";
		if(words.size() >= 1) {
			str = str + words.get(0);

			for(int j = 1; j < words.size(); j++) {
				str = str + " "+ words.get(j);
			}
		}
		return str;
	}
	
	public String getReverseLine(int i) {
		// TODO Auto-generated method stub
		ArrayList<String> words = contents.get(i).getWords();
		String str = "";
		if(words.size() >= 1) {
			str = str + words.get(words.size() - 1);

			for(int j = words.size() - 2; j >= 0 ; j--) {
				str = str + " "+ words.get(j);
			}
		}
		return str;
	}
	
	public String getEncodedLine(int i) {
		// TODO Auto-generated method stub
		ArrayList<String> words = contents.get(i).getWords();
		String str = "";
		if(words.size() >= 1) {
			str = str + words.get(0);

			for(int j = 1; j < words.size(); j++) {
				str = str + " "+ words.get(j);
			}
		}
		return encodingStrategy.encode(str);
	}

	public EncodingStrategy getEncodingStrategy() {
		// TODO Auto-generated method stub
		return encodingStrategy;
	}
}
